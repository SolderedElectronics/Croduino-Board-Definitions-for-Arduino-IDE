/* Generated automatically by the program `genconstants'
   from the machine description file `md'.  */

#ifndef GCC_INSN_CONSTANTS_H
#define GCC_INSN_CONSTANTS_H

#define A1_REG 1
#define UNSPEC_TPOFF 5
#define UNSPEC_MEMW 11
#define A8_REG 8
#define UNSPEC_TLS_ARG 8
#define UNSPEC_TLS_CALL 9
#define A9_REG 9
#define UNSPECV_SET_FP 1
#define UNSPECV_BLOCKAGE 8
#define UNSPEC_TP 10
#define UNSPECV_ENTRY 2
#define UNSPEC_NOP 2
#define UNSPEC_TLS_FUNC 7
#define UNSPECV_SET_TP 7
#define UNSPECV_S32C1I 5
#define UNSPECV_EH_RETURN 6
#define UNSPECV_S32RI 4
#define UNSPEC_PLT 3
#define UNSPEC_DTPOFF 6
#define A0_REG 0
#define UNSPEC_RET_ADDR 4
#define A7_REG 7

#endif /* GCC_INSN_CONSTANTS_H */
